import os
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, secrets, json, csv, io
from datetime import datetime

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,'school.db')
UPLOAD=os.path.join(BASE,'static','uploads')
os.makedirs(UPLOAD, exist_ok=True)
app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY') or secrets.token_hex(32)
CLASSES=['هفتم','نهم A','نهم B','دهم','یازدهم']
QUESTION_TYPES={
    'single':'چهارگزینه‌ای','multi':'چندگزینه‌ای','tf':'درست / نادرست',
    'short':'پاسخ کوتاه','fill':'جای خالی','match':'وصل‌کردنی','essay':'تشریحی','numeric':'عددی'
}

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, national_id TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, class_name TEXT);
    CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT, class_name TEXT NOT NULL, due_date TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS submissions(id INTEGER PRIMARY KEY, assignment_id INTEGER, student_id INTEGER, text TEXT, filename TEXT, submitted_at TEXT NOT NULL, UNIQUE(assignment_id,student_id));
    CREATE TABLE IF NOT EXISTS quizzes(id INTEGER PRIMARY KEY, title TEXT NOT NULL, class_name TEXT NOT NULL, duration INTEGER DEFAULT 20, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY, quiz_id INTEGER, question TEXT NOT NULL, a TEXT,b TEXT,c TEXT,d TEXT, answer TEXT NOT NULL, points REAL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY, quiz_id INTEGER, student_id INTEGER, score REAL, started_at TEXT, submitted_at TEXT, UNIQUE(quiz_id,student_id), manual_score REAL DEFAULT 0, graded INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY, student_id INTEGER, title TEXT, subject TEXT DEFAULT 'عمومی', score REAL, max_score REAL, term TEXT DEFAULT 'نوبت اول', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS quiz_answers(id INTEGER PRIMARY KEY, attempt_id INTEGER, question_id INTEGER, answer TEXT, manual_score REAL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS classes(id INTEGER PRIMARY KEY, class_name TEXT UNIQUE, meeting_url TEXT, schedule TEXT);
    CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL, class_name TEXT NOT NULL, date TEXT NOT NULL, status TEXT NOT NULL, note TEXT DEFAULT '', UNIQUE(student_id,date));
    CREATE TABLE IF NOT EXISTS announcements(id INTEGER PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, class_name TEXT NOT NULL, created_at TEXT NOT NULL, published INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS subjects(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT DEFAULT '');
    ''')
    # Upgrade old question table without breaking existing databases.
    cols={r['name'] for r in c.execute('PRAGMA table_info(questions)').fetchall()}
    if 'qtype' not in cols: c.execute("ALTER TABLE questions ADD COLUMN qtype TEXT DEFAULT 'single'")
    if 'data' not in cols: c.execute("ALTER TABLE questions ADD COLUMN data TEXT DEFAULT '{}'")
    if 'manual_score' not in {r['name'] for r in c.execute('PRAGMA table_info(attempts)').fetchall()}: c.execute("ALTER TABLE attempts ADD COLUMN manual_score REAL DEFAULT 0")
    if 'graded' not in {r['name'] for r in c.execute('PRAGMA table_info(attempts)').fetchall()}: c.execute("ALTER TABLE attempts ADD COLUMN graded INTEGER DEFAULT 0")
    grade_cols={r['name'] for r in c.execute('PRAGMA table_info(grades)').fetchall()}
    if 'subject' not in grade_cols: c.execute("ALTER TABLE grades ADD COLUMN subject TEXT DEFAULT 'عمومی'")
    if 'term' not in grade_cols: c.execute("ALTER TABLE grades ADD COLUMN term TEXT DEFAULT 'نوبت اول'")

    if not c.execute("SELECT 1 FROM users WHERE role='teacher'").fetchone():
        c.execute("INSERT INTO users(national_id,name,password_hash,role) VALUES(?,?,?,?)",('teacher','عزیزه مظفری',generate_password_hash('teacher123'),'teacher'))
        for cl in CLASSES: c.execute("INSERT OR IGNORE INTO classes(class_name,meeting_url,schedule) VALUES(?,?,?)",(cl,'',''))
        for i,cl in enumerate(CLASSES,1):
            c.execute("INSERT INTO users(national_id,name,password_hash,role,class_name) VALUES(?,?,?,?,?)",(f'100{i}',f'دانش‌آموز نمونه {i}',generate_password_hash('12345678'),'student',cl))
    default_subjects=['تاریخ','جامعه‌شناسی','اقتصاد','تفکر و سواد رسانه‌ای']
    for sub in default_subjects: c.execute('INSERT OR IGNORE INTO subjects(name) VALUES(?)',(sub,))
    c.commit(); c.close()
init()

def get_classes(c=None):
    own=False
    if c is None: c=db(); own=True
    rows=c.execute('SELECT class_name FROM classes ORDER BY id').fetchall()
    names=[r['class_name'] for r in rows]
    for cl in CLASSES:
        if cl not in names: names.append(cl)
    if own: c.close()
    return names

def get_subjects(c=None):
    own=False
    if c is None: c=db(); own=True
    rows=c.execute('SELECT name FROM subjects WHERE active=1 ORDER BY name').fetchall()
    names=[r['name'] for r in rows]
    if own: c.close()
    return names

def current():
    if 'uid' not in session:return None
    c=db(); u=c.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone(); c.close(); return u

def teacher_required(): return bool(current() and current()['role']=='teacher')

def parse_data(q):
    try: return json.loads(q['data'] or '{}')
    except Exception: return {}

def auto_score(q, raw):
    data=parse_data(q); typ=q['qtype'] or 'single'; pts=float(q['points'] or 1)
    if raw is None: return 0.0
    if typ=='single' or typ=='tf': return pts if raw==q['answer'] else 0.0
    if typ=='multi':
        got=sorted(request.form.getlist(f'q{q["id"]}'))
        correct=sorted(data.get('correct',[]))
        return pts if got==correct else 0.0
    if typ in ('short','fill'):
        got=raw.strip().casefold(); answers=[str(x).strip().casefold() for x in data.get('answers',[]) if str(x).strip()]
        return pts if got in answers else 0.0
    if typ=='numeric':
        try: return pts if abs(float(raw)-float(data.get('answer'))) <= float(data.get('tolerance',0)) else 0.0
        except Exception: return 0.0
    if typ=='match':
        got={k:request.form.get(f'q{q["id"]}_{idx}','') for idx,k in enumerate(data.get('left',[]))}
        return pts if got==data.get('correct',{}) else 0.0
    # essay is manually graded by teacher later.
    return 0.0

@app.route('/',methods=['GET','POST'])
def login():
    if request.method=='POST':
        nid=request.form['national_id'].strip(); pw=request.form['password']
        c=db(); u=c.execute('SELECT * FROM users WHERE national_id=?',(nid,)).fetchone(); c.close()
        if u and check_password_hash(u['password_hash'],pw): session['uid']=u['id']; return redirect(url_for('dashboard'))
        flash('کد ملی یا رمز عبور نادرست است.','error')
    return render_template('login.html')

@app.get('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.get('/dashboard')
def dashboard():
    u=current()
    if not u:return redirect(url_for('login'))
    c=db()
    if u['role']=='teacher':
        stats={
            'students':c.execute("SELECT COUNT(*) n FROM users WHERE role='student'").fetchone()['n'],
            'assignments':c.execute('SELECT COUNT(*) n FROM assignments').fetchone()['n'],
            'quizzes':c.execute('SELECT COUNT(*) n FROM quizzes').fetchone()['n'],
            'content':c.execute("SELECT COUNT(*) n FROM lesson_content").fetchone()['n'] if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='lesson_content'").fetchone() else 0,
            'announcements':c.execute("SELECT COUNT(*) n FROM announcements").fetchone()['n'] if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='announcements'").fetchone() else 0,
            'grades':c.execute("SELECT COUNT(*) n FROM grades").fetchone()['n']
        }
        class_counts=c.execute("SELECT class_name, COUNT(*) n FROM users WHERE role='student' GROUP BY class_name ORDER BY class_name").fetchall()
        classes=c.execute('SELECT * FROM classes').fetchall()
        recent=c.execute("SELECT * FROM announcements ORDER BY id DESC LIMIT 5").fetchall() if 'announcements' in [r['name'] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()] else []
        c.close()
        return render_template('teacher.html',user=u,stats=stats,classes=classes,class_counts=class_counts,recent_announcements=recent)

    assignments=c.execute('SELECT a.*,s.id sid FROM assignments a LEFT JOIN submissions s ON s.assignment_id=a.id AND s.student_id=? WHERE a.class_name=? ORDER BY a.id DESC',(u['id'],u['class_name'])).fetchall()
    quizzes=c.execute('SELECT * FROM quizzes WHERE class_name=? ORDER BY id DESC',(u['class_name'],)).fetchall()
    grades=c.execute('SELECT * FROM grades WHERE student_id=? ORDER BY id DESC',(u['id'],)).fetchall()
    classes=c.execute('SELECT * FROM classes WHERE class_name=?',(u['class_name'],)).fetchall()
    ann=[]
    if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='announcements'").fetchone():
        ann=c.execute("""SELECT * FROM announcements WHERE published=1
                         AND (class_name='همه کلاس‌ها' OR class_name=?)
                         ORDER BY id DESC LIMIT 5""",(u['class_name'],)).fetchall()
    attendance_summary=c.execute("""SELECT
        SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) present,
        SUM(CASE WHEN status='absent' THEN 1 ELSE 0 END) absent,
        SUM(CASE WHEN status='late' THEN 1 ELSE 0 END) late
        FROM attendance WHERE student_id=?""",(u['id'],)).fetchone()
    c.close()
    return render_template('student.html',user=u,assignments=assignments,quizzes=quizzes,grades=grades,classes=classes,announcements=ann,attendance_summary=attendance_summary)

@app.post('/admin/class/<int:cid>')
def update_class(cid):
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); c.execute('UPDATE classes SET meeting_url=?,schedule=? WHERE id=?',(request.form.get('meeting_url',''),request.form.get('schedule',''),cid)); c.commit(); c.close(); flash('اطلاعات کلاس ذخیره شد.','ok'); return redirect(url_for('dashboard'))

@app.route('/admin/students',methods=['GET','POST'])
def students():
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    if request.method=='POST':
        try:
            c.execute('INSERT INTO users(national_id,name,password_hash,role,class_name) VALUES(?,?,?,?,?)',(request.form['national_id'],request.form['name'],generate_password_hash(request.form['password']), 'student',request.form['class_name']))
            c.commit(); flash('دانش‌آموز اضافه شد.','ok')
        except sqlite3.IntegrityError: flash('این کد ملی قبلاً ثبت شده است.','error')
    users=c.execute("SELECT * FROM users WHERE role='student' ORDER BY class_name,name").fetchall(); c.close(); return render_template('students.html',students=users,classes=get_classes(c),subjects=get_subjects(c))

@app.post('/admin/assignment')
def create_assignment():
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); c.execute('INSERT INTO assignments(title,description,class_name,due_date,created_at) VALUES(?,?,?,?,?)',(request.form['title'],request.form.get('description',''),request.form['class_name'],request.form.get('due_date',''),datetime.now().isoformat(timespec='minutes'))); c.commit(); c.close(); flash('تکلیف ایجاد شد.','ok'); return redirect(url_for('dashboard'))

@app.get('/admin/submissions')
def all_submissions():
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); rows=c.execute('''SELECT s.*,a.title,u.name,u.national_id,a.class_name FROM submissions s JOIN assignments a ON a.id=s.assignment_id JOIN users u ON u.id=s.student_id ORDER BY s.id DESC''').fetchall(); c.close(); return render_template('submissions.html',rows=rows)

@app.post('/assignment/<int:aid>/submit')
def submit_assignment(aid):
    u=current()
    if not u or u['role']!='student': return redirect(url_for('login'))
    c=db(); a=c.execute('SELECT * FROM assignments WHERE id=? AND class_name=?',(aid,u['class_name'])).fetchone()
    if not a: c.close(); return 'Not found',404
    text=request.form.get('text',''); f=request.files.get('file'); filename=''
    if f and f.filename:
        ext=os.path.splitext(f.filename)[1][:10]; filename=f'{u["id"]}_{aid}_{secrets.token_hex(6)}{ext}'; f.save(os.path.join(UPLOAD,filename))
    c.execute('INSERT INTO submissions(assignment_id,student_id,text,filename,submitted_at) VALUES(?,?,?,?,?) ON CONFLICT(assignment_id,student_id) DO UPDATE SET text=excluded.text,filename=excluded.filename,submitted_at=excluded.submitted_at',(aid,u['id'],text,filename,datetime.now().isoformat(timespec='minutes'))); c.commit(); c.close(); flash('تکلیف با موفقیت ارسال شد.','ok'); return redirect(url_for('dashboard'))

@app.get('/uploads/<path:name>')
def uploads(name):
    if not teacher_required(): return 'Forbidden',403
    return send_from_directory(UPLOAD,name,as_attachment=True)

@app.route('/admin/quiz',methods=['GET','POST'])
def create_quiz():
    if not teacher_required(): return redirect(url_for('login'))
    if request.method=='POST':
        c=db(); c.execute('INSERT INTO quizzes(title,class_name,duration,created_at) VALUES(?,?,?,?)',(request.form['title'],request.form['class_name'],int(request.form.get('duration',20)),datetime.now().isoformat(timespec='minutes'))); qid=c.execute('SELECT last_insert_rowid()').fetchone()[0]
        count=int(request.form.get('count',1))
        for i in range(1,count+1):
            typ=request.form.get(f'type{i}','single'); text=request.form.get(f'q{i}','').strip();
            if not text: continue
            points=float(request.form.get(f'points{i}',1) or 1); data={}; a=b=copt=d=''; answer=''
            if typ=='single':
                a=request.form.get(f'a{i}',''); b=request.form.get(f'b{i}',''); copt=request.form.get(f'c{i}',''); d=request.form.get(f'd{i}',''); answer=request.form.get(f'answer{i}','a')
            elif typ=='multi':
                a=request.form.get(f'a{i}',''); b=request.form.get(f'b{i}',''); copt=request.form.get(f'c{i}',''); d=request.form.get(f'd{i}',''); data={'correct':request.form.getlist(f'correct{i}')}; answer=','.join(data['correct'])
            elif typ=='tf': answer=request.form.get(f'tf{i}','true')
            elif typ in ('short','fill'): data={'answers':[x.strip() for x in request.form.get(f'answers{i}','').split('|') if x.strip()]}; answer=data['answers'][0] if data['answers'] else ''
            elif typ=='numeric': data={'answer':request.form.get(f'num{i}',''),'tolerance':request.form.get(f'tol{i}','0')}; answer=data['answer']
            elif typ=='match':
                left=[x.strip() for x in request.form.get(f'left{i}','').split('|') if x.strip()]; right=[x.strip() for x in request.form.get(f'right{i}','').split('|') if x.strip()]; correct={}
                for idx,item in enumerate(left): correct[item]=request.form.get(f'match{i}_{idx}','')
                data={'left':left,'right':right,'correct':correct}; answer=json.dumps(correct,ensure_ascii=False)
            elif typ=='essay': pass
            c.execute('INSERT INTO questions(quiz_id,question,a,b,c,d,answer,points,qtype,data) VALUES(?,?,?,?,?,?,?,?,?,?)',(qid,text,a,b,copt,d,answer,points,typ,json.dumps(data,ensure_ascii=False)))
        c.commit(); c.close(); flash('آزمون تلفیقی با موفقیت ایجاد شد.','ok'); return redirect(url_for('dashboard'))
    return render_template('quiz_new.html',classes=CLASSES,types=QUESTION_TYPES)

@app.get('/quiz/<int:qid>')
def take_quiz(qid):
    u=current()
    if not u or u['role']!='student': return redirect(url_for('login'))
    c=db(); q=c.execute('SELECT * FROM quizzes WHERE id=? AND class_name=?',(qid,u['class_name'])).fetchone(); qs=c.execute('SELECT * FROM questions WHERE quiz_id=?',(qid,)).fetchall(); old=c.execute('SELECT * FROM attempts WHERE quiz_id=? AND student_id=?',(qid,u['id'])).fetchone(); c.close()
    if not q:return 'Not found',404
    if old:return render_template('quiz_result.html',quiz=q,attempt=old)
    return render_template('quiz.html',quiz=q,questions=qs,parse_data=parse_data,types=QUESTION_TYPES)

@app.post('/quiz/<int:qid>/submit')
def submit_quiz(qid):
    u=current()
    if not u or u['role']!='student': return redirect(url_for('login'))
    c=db(); qz=c.execute('SELECT * FROM quizzes WHERE id=? AND class_name=?',(qid,u['class_name'])).fetchone()
    qs=c.execute('SELECT * FROM questions WHERE quiz_id=?',(qid,)).fetchall()
    if not qz: c.close(); return 'Not found',404
    old=c.execute('SELECT * FROM attempts WHERE quiz_id=? AND student_id=?',(qid,u['id'])).fetchone()
    if old: c.close(); return redirect(url_for('take_quiz',qid=qid))
    score=0
    for q in qs:
        raw=request.form.get(f'q{q["id"]}')
        score += auto_score(q,raw)
    maxscore=sum(float(q['points'] or 1) for q in qs)
    has_essay=any(q['qtype']=='essay' for q in qs)
    c.execute('INSERT INTO attempts(quiz_id,student_id,score,started_at,submitted_at,manual_score,graded) VALUES(?,?,?,?,?,?,?)',
              (qid,u['id'],score,datetime.now().isoformat(timespec='minutes'),datetime.now().isoformat(timespec='minutes'),0,0 if has_essay else 1))
    aid=c.execute('SELECT last_insert_rowid()').fetchone()[0]
    for q in qs:
        raw=request.form.get(f'q{q["id"]}')
        if raw is None and q['qtype']=='multi':
            raw=','.join(request.form.getlist(f'q{q["id"]}'))
        c.execute('INSERT INTO quiz_answers(attempt_id,question_id,answer,manual_score) VALUES(?,?,?,0)',
                  (aid,q['id'],raw or ''))
    c.commit(); c.close(); return redirect(url_for('take_quiz',qid=qid))

@app.get('/admin/quiz-results')
def quiz_results():
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    rows=c.execute("""SELECT a.id attempt_id,a.score,a.manual_score,a.graded,a.submitted_at,
                             q.id quiz_id,q.title,q.class_name,u.id student_id,u.name student_name
                      FROM attempts a JOIN quizzes q ON q.id=a.quiz_id
                      JOIN users u ON u.id=a.student_id
                      ORDER BY a.id DESC""").fetchall()
    c.close()
    return render_template('quiz_results.html',results=rows)

@app.route('/admin/quiz-result/<int:attempt_id>',methods=['GET','POST'])
def grade_quiz_result(attempt_id):
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    attempt=c.execute("""SELECT a.*,q.title,q.class_name,u.name student_name,u.id student_id
                         FROM attempts a JOIN quizzes q ON q.id=a.quiz_id
                         JOIN users u ON u.id=a.student_id WHERE a.id=?""",(attempt_id,)).fetchone()
    if not attempt: c.close(); return 'Not found',404
    rows=c.execute("""SELECT qa.*,qu.question,qu.points,qu.qtype
                      FROM quiz_answers qa JOIN questions qu ON qu.id=qa.question_id
                      WHERE qa.attempt_id=? ORDER BY qu.id""",(attempt_id,)).fetchall()
    if request.method=='POST':
        manual=0
        for r in rows:
            val=float(request.form.get(f'score_{r["id"]}',0) or 0)
            pts=float(r['points'] or 0)
            val=max(0,min(val,pts))
            c.execute("UPDATE quiz_answers SET manual_score=? WHERE id=?",(val,r['id']))
            manual+=val
        c.execute("UPDATE attempts SET manual_score=?,graded=1 WHERE id=?",(manual,attempt_id))
        # Keep a grade entry visible to the student.
        total=float(attempt['score'] or 0)+manual
        maxscore=sum(float(r['points'] or 0) for r in rows)
        c.execute("DELETE FROM grades WHERE student_id=? AND title=?",(attempt['student_id'],f"آزمون: {attempt['title']}"))
        c.execute("INSERT INTO grades(student_id,title,score,max_score,created_at) VALUES(?,?,?,?,?)",
                  (attempt['student_id'],f"آزمون: {attempt['title']}",total,maxscore,datetime.now().isoformat(timespec='minutes')))
        c.commit(); c.close(); flash('نمره آزمون ثبت شد.','ok')
        return redirect(url_for('quiz_results'))
    c.close()
    return render_template('quiz_grade.html',attempt=attempt,answers=rows)

@app.post('/admin/grade')
def grade():
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    c.execute('INSERT INTO grades(student_id,title,subject,score,max_score,term,created_at) VALUES(?,?,?,?,?,?,?)',
              (int(request.form['student_id']),request.form.get('title','').strip(),request.form.get('subject','عمومی').strip(),
               float(request.form['score']),float(request.form.get('max_score',20)),request.form.get('term','نوبت اول'),
               datetime.now().isoformat(timespec='minutes')))
    c.commit(); c.close(); flash('نمره ثبت شد.','ok'); return redirect(url_for('gradebook'))

@app.get('/admin/gradebook')
def gradebook():
    if not teacher_required(): return redirect(url_for('login'))
    selected_class=request.args.get('class_name', CLASSES[0])
    selected_subject=request.args.get('subject','همه درس‌ها')
    c=db()
    students=c.execute("SELECT * FROM users WHERE role='student' AND class_name=? ORDER BY name",(selected_class,)).fetchall()
    subjects=[r['subject'] for r in c.execute("SELECT DISTINCT subject FROM grades g JOIN users u ON u.id=g.student_id WHERE u.class_name=? AND subject IS NOT NULL AND subject<>'' ORDER BY subject",(selected_class,)).fetchall()]
    query="SELECT u.id uid,u.name,u.national_id,g.id gid,g.subject,g.title,g.score,g.max_score,g.term,g.created_at FROM users u LEFT JOIN grades g ON g.student_id=u.id WHERE u.role='student' AND u.class_name=?"
    params=[selected_class]
    if selected_subject!='همه درس‌ها': query += " AND g.subject=?"; params.append(selected_subject)
    rows=c.execute(query+" ORDER BY u.name,g.subject,g.id DESC",params).fetchall(); c.close()
    data={}
    for r in rows:
        if r['uid'] not in data: data[r['uid']]={'student':r,'grades':[]}
        if r['gid']: data[r['uid']]['grades'].append(r)
    return render_template('gradebook.html',classes=CLASSES,students=list(data.values()),selected_class=selected_class,selected_subject=selected_subject,subjects=subjects)

@app.get('/admin/report/<int:sid>')
def student_report(sid):
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); student=c.execute("SELECT * FROM users WHERE id=? AND role='student'",(sid,)).fetchone()
    if not student: c.close(); return 'Not found',404
    grades=c.execute("SELECT * FROM grades WHERE student_id=? ORDER BY subject,term,id",(sid,)).fetchall(); c.close()
    by_subject={}
    for g in grades: by_subject.setdefault(g['subject'] or 'عمومی',[]).append(g)
    subject_rows=[]; total=total_max=0
    for subject,items in by_subject.items():
        earned=sum(float(x['score']) for x in items); maximum=sum(float(x['max_score']) for x in items if float(x['max_score'])>0)
        score20=(earned/maximum*20) if maximum else 0
        subject_rows.append({'subject':subject,'earned':earned,'maximum':maximum,'score20':score20}); total+=earned; total_max+=maximum
    average=(total/total_max*20) if total_max else 0
    return render_template('student_report.html',student=student,subject_rows=subject_rows,average=average,grades=grades)

@app.route('/admin/grade/<int:gid>/edit', methods=['GET','POST'])
def edit_grade(gid):
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    grade=c.execute("""SELECT g.*,u.name student_name,u.class_name FROM grades g
                     JOIN users u ON u.id=g.student_id
                     WHERE g.id=? AND u.role='student'""",(gid,)).fetchone()
    if not grade:
        c.close(); return 'Not found',404
    if request.method=='POST':
        title=request.form.get('title','').strip()
        subject=request.form.get('subject','').strip() or 'عمومی'
        term=request.form.get('term','نوبت اول').strip() or 'نوبت اول'
        try:
            score=float(request.form.get('score','0'))
            max_score=float(request.form.get('max_score','20'))
        except ValueError:
            score=max_score=-1
        if not title or max_score<=0 or score<0 or score>max_score:
            flash('عنوان، سقف نمره و نمره را صحیح وارد کنید.','error')
            c.close(); return redirect(url_for('edit_grade',gid=gid))
        c.execute("UPDATE grades SET title=?,subject=?,score=?,max_score=?,term=? WHERE id=?",
                  (title,subject,score,max_score,term,gid))
        c.commit(); c.close(); flash('نمره با موفقیت ویرایش شد.','ok')
        return redirect(url_for('gradebook',class_name=grade['class_name'],subject=subject))
    c.close()
    return render_template('grade_edit.html',grade=grade)

@app.get('/admin/class-report')
def class_report():
    if not teacher_required(): return redirect(url_for('login'))
    selected_class=request.args.get('class_name',CLASSES[0])
    selected_term=request.args.get('term','همه نوبت‌ها')
    c=db()
    students=c.execute("SELECT id,name,national_id FROM users WHERE role='student' AND class_name=? ORDER BY name",(selected_class,)).fetchall()
    where="u.class_name=?"; params=[selected_class]
    if selected_term!='همه نوبت‌ها': where += " AND g.term=?"; params.append(selected_term)
    rows=c.execute(f"""SELECT u.id sid,u.name,g.subject,g.score,g.max_score
                       FROM users u LEFT JOIN grades g ON g.student_id=u.id
                       WHERE u.role='student' AND {where}
                       ORDER BY u.name,g.subject""",params).fetchall()
    c.close()
    data={s['id']:{'name':s['name'],'national_id':s['national_id'],'earned':0,'maximum':0,'average':0,'count':0} for s in students}
    subject_totals={}
    for r in rows:
        if r['sid'] not in data or r['score'] is None: continue
        score=float(r['score']); maximum=float(r['max_score'] or 0)
        data[r['sid']]['earned']+=score; data[r['sid']]['maximum']+=maximum; data[r['sid']]['count']+=1
        sub=r['subject'] or 'عمومی'
        st=subject_totals.setdefault(sub,{'earned':0,'maximum':0,'count':0})
        st['earned']+=score; st['maximum']+=maximum; st['count']+=1
    report=[]
    for x in data.values():
        x['average']=(x['earned']/x['maximum']*20) if x['maximum'] else 0
        report.append(x)
    class_avg=(sum(x['earned'] for x in report)/sum(x['maximum'] for x in report)*20) if sum(x['maximum'] for x in report) else 0
    subjects=[]
    for sub,x in subject_totals.items():
        x['average']=(x['earned']/x['maximum']*20) if x['maximum'] else 0
        subjects.append({'subject':sub,**x})
    subjects.sort(key=lambda x:x['subject'])
    report.sort(key=lambda x:x['name'])
    return render_template('class_report.html',classes=CLASSES,terms=['همه نوبت‌ها','نوبت اول','نوبت دوم','مستمر'],selected_class=selected_class,selected_term=selected_term,report=report,subjects=subjects,class_avg=class_avg)

@app.get('/admin/analytics')
def analytics():
    if not teacher_required(): return redirect(url_for('login'))
    selected_class=request.args.get('class_name', CLASSES[0])
    selected_term=request.args.get('term','همه نوبت‌ها')
    c=db()
    students=c.execute("SELECT id,name,national_id FROM users WHERE role='student' AND class_name=? ORDER BY name",(selected_class,)).fetchall()
    where="u.class_name=?"; params=[selected_class]
    if selected_term!='همه نوبت‌ها':
        where += " AND g.term=?"; params.append(selected_term)
    rows=c.execute(f"""SELECT u.id sid,u.name,g.subject,g.score,g.max_score,g.term,g.title
                       FROM users u LEFT JOIN grades g ON g.student_id=u.id
                       WHERE u.role='student' AND {where}
                       ORDER BY u.name,g.subject,g.id""",params).fetchall()
    c.close()

    data={s['id']:{'id':s['id'],'name':s['name'],'earned':0.0,'maximum':0.0,'count':0,'subjects':{}} for s in students}
    subject_totals={}
    term_totals={}
    for r in rows:
        if r['sid'] not in data or r['score'] is None: continue
        score=float(r['score'] or 0); maximum=float(r['max_score'] or 0)
        if maximum<=0: continue
        d=data[r['sid']]
        d['earned']+=score; d['maximum']+=maximum; d['count']+=1
        subject=r['subject'] or 'عمومی'; term=r['term'] or 'بدون نوبت'
        d['subjects'].setdefault(subject,{'earned':0.0,'maximum':0.0,'count':0})
        d['subjects'][subject]['earned']+=score; d['subjects'][subject]['maximum']+=maximum; d['subjects'][subject]['count']+=1
        st=subject_totals.setdefault(subject,{'earned':0.0,'maximum':0.0,'count':0})
        st['earned']+=score; st['maximum']+=maximum; st['count']+=1
        tt=term_totals.setdefault(term,{'earned':0.0,'maximum':0.0,'count':0})
        tt['earned']+=score; tt['maximum']+=maximum; tt['count']+=1

    report=[]
    for d in data.values():
        d['average']=(d['earned']/d['maximum']*20) if d['maximum'] else 0
        d['level']='عالی' if d['average']>=18 else ('خوب' if d['average']>=15 else ('نیازمند پیگیری' if d['average']>0 else 'بدون نمره'))
        report.append(d)
    report.sort(key=lambda x:x['average'],reverse=True)
    class_avg=(sum(x['earned'] for x in report)/sum(x['maximum'] for x in report)*20) if sum(x['maximum'] for x in report) else 0
    subjects=[]
    for name,x in subject_totals.items():
        avg=(x['earned']/x['maximum']*20) if x['maximum'] else 0
        subjects.append({'subject':name,'average':avg,'count':x['count']})
    subjects.sort(key=lambda x:x['average'],reverse=True)
    terms=[]
    for name,x in term_totals.items():
        avg=(x['earned']/x['maximum']*20) if x['maximum'] else 0
        terms.append({'term':name,'average':avg,'count':x['count']})
    terms.sort(key=lambda x:x['term'])
    distribution={'عالی (۱۸ تا ۲۰)':0,'خوب (۱۵ تا ۱۷٫۹۹)':0,'نیازمند پیگیری (کمتر از ۱۵)':0,'بدون نمره':0}
    for d in report:
        if d['average']==0: distribution['بدون نمره']+=1
        elif d['average']>=18: distribution['عالی (۱۸ تا ۲۰)']+=1
        elif d['average']>=15: distribution['خوب (۱۵ تا ۱۷٫۹۹)']+=1
        else: distribution['نیازمند پیگیری (کمتر از ۱۵)']+=1
    top=report[:3]
    return render_template('analytics.html',classes=CLASSES,terms=['همه نوبت‌ها','نوبت اول','نوبت دوم','مستمر'],selected_class=selected_class,selected_term=selected_term,report=report,subjects=subjects,terms_data=terms,distribution=distribution,class_avg=class_avg,top=top)

@app.post('/admin/grade/<int:gid>/delete')
def delete_grade(gid):
    if not teacher_required(): return redirect(url_for('gradebook'))
    c=db(); c.execute("DELETE FROM grades WHERE id=?",(gid,)); c.commit(); c.close(); flash('نمره حذف شد.','ok'); return redirect(request.referrer or url_for('gradebook'))


@app.route('/admin/attendance', methods=['GET','POST'])
def attendance():
    if not teacher_required(): return redirect(url_for('login'))
    selected_class=request.values.get('class_name', CLASSES[0])
    selected_date=request.values.get('date', datetime.now().date().isoformat())
    c=db()
    students=c.execute("SELECT * FROM users WHERE role='student' AND class_name=? ORDER BY name",(selected_class,)).fetchall()
    if request.method=='POST':
        for st in students:
            status=request.form.get(f"status_{st['id']}","present")
            note=request.form.get(f"note_{st['id']}","").strip()
            c.execute("""INSERT INTO attendance(student_id,class_name,date,status,note)
                         VALUES(?,?,?,?,?)
                         ON CONFLICT(student_id,date) DO UPDATE SET
                         class_name=excluded.class_name,status=excluded.status,note=excluded.note""",
                      (st['id'],selected_class,selected_date,status,note))
        c.commit(); c.close(); flash('حضور و غیاب با موفقیت ذخیره شد.','ok')
        return redirect(url_for('attendance',class_name=selected_class,date=selected_date))
    rows=c.execute("SELECT * FROM attendance WHERE class_name=? AND date=?",(selected_class,selected_date)).fetchall()
    records={r['student_id']:r for r in rows}; c.close()
    return render_template('attendance.html',classes=CLASSES,students=students,records=records,selected_class=selected_class,selected_date=selected_date)

@app.get('/student/attendance')
def student_attendance():
    u=current()
    if not u or u['role']!='student': return redirect(url_for('login'))
    c=db(); records=c.execute("SELECT * FROM attendance WHERE student_id=? ORDER BY date DESC",(u['id'],)).fetchall(); c.close()
    return render_template('student_attendance.html',records=records)



@app.route('/admin/student/<int:sid>/edit', methods=['GET','POST'])
def edit_student(sid):
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); student=c.execute("SELECT * FROM users WHERE id=? AND role='student'",(sid,)).fetchone()
    if not student:
        c.close(); return 'Not found',404
    if request.method=='POST':
        name=request.form.get('name','').strip(); nid=request.form.get('national_id','').strip(); cl=request.form.get('class_name','').strip()
        if not name or not nid or cl not in get_classes(c):
            flash('نام، کد ملی و کلاس را صحیح وارد کنید.','error'); c.close(); return redirect(url_for('edit_student',sid=sid))
        try:
            c.execute("UPDATE users SET name=?,national_id=?,class_name=? WHERE id=? AND role='student'",(name,nid,cl,sid)); c.commit(); flash('اطلاعات دانش‌آموز ویرایش شد.','ok')
        except sqlite3.IntegrityError: flash('این کد ملی قبلاً ثبت شده است.','error')
        c.close(); return redirect(url_for('students'))
    c.close(); return render_template('student_edit.html',student=student,classes=get_classes(c))

@app.get('/admin/export/grades.csv')
def export_grades():
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); rows=c.execute("""SELECT u.name student_name,u.national_id,u.class_name,g.subject,g.title,g.term,g.score,g.max_score,g.created_at
                              FROM grades g JOIN users u ON u.id=g.student_id
                              WHERE u.role='student' ORDER BY u.class_name,u.name,g.subject,g.id""").fetchall(); c.close()
    out=io.StringIO(); w=csv.writer(out); w.writerow(['نام دانش‌آموز','کد ملی','کلاس','درس','عنوان ارزیابی','نوبت','نمره','سقف نمره','تاریخ'])
    for r in rows: w.writerow([r['student_name'],r['national_id'],r['class_name'],r['subject'],r['title'],r['term'],r['score'],r['max_score'],r['created_at']])
    data='\ufeff'+out.getvalue()
    return app.response_class(data, mimetype='text/csv; charset=utf-8', headers={'Content-Disposition':'attachment; filename=grades_export.csv'})

@app.get('/admin/export/students.csv')
def export_students():
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); rows=c.execute("SELECT name,national_id,class_name FROM users WHERE role='student' ORDER BY class_name,name").fetchall(); c.close()
    out=io.StringIO(); w=csv.writer(out); w.writerow(['نام دانش‌آموز','کد ملی','کلاس'])
    for r in rows: w.writerow([r['name'],r['national_id'],r['class_name']])
    data='\ufeff'+out.getvalue()
    return app.response_class(data, mimetype='text/csv; charset=utf-8', headers={'Content-Disposition':'attachment; filename=students_export.csv'})

@app.post('/admin/student/<int:sid>/delete')
def delete_student(sid):
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    c.execute("DELETE FROM submissions WHERE student_id=?",(sid,))
    c.execute("DELETE FROM attempts WHERE student_id=?",(sid,))
    c.execute("DELETE FROM grades WHERE student_id=?",(sid,))
    c.execute("DELETE FROM attendance WHERE student_id=?",(sid,))
    c.execute("DELETE FROM users WHERE id=? AND role='student'",(sid,))
    c.commit(); c.close(); flash('دانش‌آموز حذف شد.','ok')
    return redirect(url_for('students'))

@app.post('/admin/student/<int:sid>/password')
def reset_student_password(sid):
    if not teacher_required(): return redirect(url_for('login'))
    pw=request.form.get('password','').strip()
    if len(pw)<4:
        flash('رمز عبور باید حداقل ۴ کاراکتر باشد.','error')
        return redirect(url_for('students'))
    c=db(); c.execute("UPDATE users SET password_hash=? WHERE id=? AND role='student'",(generate_password_hash(pw),sid)); c.commit(); c.close()
    flash('رمز عبور دانش‌آموز تغییر کرد.','ok')
    return redirect(url_for('students'))


@app.route('/admin/announcements', methods=['GET','POST'])
def announcements():
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    if request.method=='POST':
        title=request.form.get('title','').strip()
        body=request.form.get('body','').strip()
        class_name=request.form.get('class_name','همه کلاس‌ها')
        published=1 if request.form.get('published') else 0
        if title and body:
            c.execute("INSERT INTO announcements(title,body,class_name,created_at,published) VALUES(?,?,?,?,?)",
                      (title,body,class_name,datetime.now().isoformat(timespec='minutes'),published))
            c.commit(); flash('اطلاعیه ثبت شد.','ok')
        else: flash('عنوان و متن اطلاعیه الزامی است.','error')
    rows=c.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()
    c.close()
    return render_template('announcements.html',announcements=rows,classes=['همه کلاس‌ها']+get_classes(c))

@app.post('/admin/announcement/<int:aid>/delete')
def delete_announcement(aid):
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); c.execute("DELETE FROM announcements WHERE id=?",(aid,)); c.commit(); c.close()
    flash('اطلاعیه حذف شد.','ok'); return redirect(url_for('announcements'))

@app.get('/student/announcements')
def student_announcements():
    u=current()
    if not u or u['role']!='student': return redirect(url_for('login'))
    c=db()
    rows=c.execute("""SELECT * FROM announcements
                      WHERE published=1 AND (class_name='همه کلاس‌ها' OR class_name=?)
                      ORDER BY id DESC""",(u['class_name'],)).fetchall()
    c.close()
    return render_template('student_announcements.html',announcements=rows)



@app.route('/admin/settings', methods=['GET','POST'])
def settings():
    if not teacher_required(): return redirect(url_for('login'))
    c=db()
    if request.method=='POST':
        action=request.form.get('action','')
        if action=='add_class':
            name=request.form.get('class_name','').strip()
            if name:
                try:
                    c.execute('INSERT INTO classes(class_name,meeting_url,schedule) VALUES(?,?,?)',(name,'',''))
                    c.commit(); flash('کلاس جدید اضافه شد.','ok')
                except sqlite3.IntegrityError: flash('این کلاس قبلاً وجود دارد.','error')
        elif action=='add_subject':
            name=request.form.get('subject_name','').strip()
            if name:
                try: c.execute('INSERT INTO subjects(name) VALUES(?)',(name,)); c.commit(); flash('درس اضافه شد.','ok')
                except sqlite3.IntegrityError: flash('این درس قبلاً وجود دارد.','error')
        elif action=='delete_subject':
            sid=request.form.get('subject_id')
            c.execute('UPDATE subjects SET active=0 WHERE id=?',(sid,)); c.commit(); flash('درس غیرفعال شد.','ok')
        elif action=='delete_class':
            cid=request.form.get('class_id')
            row=c.execute('SELECT class_name FROM classes WHERE id=?',(cid,)).fetchone()
            if row and not c.execute("SELECT 1 FROM users WHERE role='student' AND class_name=? LIMIT 1",(row['class_name'],)).fetchone():
                c.execute('DELETE FROM classes WHERE id=?',(cid,)); c.commit(); flash('کلاس حذف شد.','ok')
            else: flash('کلاسی که دانش‌آموز دارد حذف نمی‌شود.','error')
    classes=c.execute('SELECT * FROM classes ORDER BY id').fetchall(); subjects=c.execute('SELECT * FROM subjects ORDER BY active DESC,name').fetchall()
    c.close(); return render_template('settings.html',classes=classes,subjects=subjects)

@app.get('/admin/backup')
def backup_data():
    if not teacher_required(): return redirect(url_for('login'))
    c=db(); tables=['users','classes','subjects','assignments','submissions','quizzes','questions','attempts','quiz_answers','grades','attendance','announcements']
    payload={'version':'v16','created_at':datetime.now().isoformat(timespec='seconds'),'tables':{}}
    for t in tables:
        rows=c.execute(f'SELECT * FROM {t}').fetchall(); payload['tables'][t]=[dict(r) for r in rows]
    c.close(); data=json.dumps(payload,ensure_ascii=False,indent=2)
    return app.response_class(data,mimetype='application/json; charset=utf-8',headers={'Content-Disposition':'attachment; filename=school_backup.json'})

@app.route('/profile', methods=['GET','POST'])
def profile():
    u=current()
    if not u: return redirect(url_for('login'))
    c=db()
    if request.method=='POST':
        old=request.form.get('old_password','')
        new=request.form.get('new_password','')
        confirm=request.form.get('confirm_password','')
        if not check_password_hash(u['password_hash'], old):
            flash('رمز عبور فعلی نادرست است.','error')
        elif len(new)<4:
            flash('رمز جدید باید حداقل ۴ کاراکتر باشد.','error')
        elif new!=confirm:
            flash('تکرار رمز جدید یکسان نیست.','error')
        else:
            c.execute("UPDATE users SET password_hash=? WHERE id=?",
                      (generate_password_hash(new),u['id']))
            c.commit(); flash('رمز عبور با موفقیت تغییر کرد.','ok')
        c.close()
        return redirect(url_for('profile'))
    c.close()
    return render_template('profile.html',user=u)

@app.get('/health')
def health():
    c=db()
    try:
        c.execute('SELECT 1')
        return {'status':'ok','version':'v16','database':'ok'}
    finally:
        c.close()

if __name__=='__main__': app.run(debug=True)
